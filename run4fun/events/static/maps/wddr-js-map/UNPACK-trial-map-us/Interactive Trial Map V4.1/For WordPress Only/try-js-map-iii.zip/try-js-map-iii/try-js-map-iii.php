<?php
/*
Plugin Name: TRIAL JS MAP III
Plugin URI: https://www.html5interactivemaps.com/
Description: Customize the colors, links, etc and use the shortcode in your pages.
Version: 4.1
Author: HTML5 Interactive Maps
Author URI: https://www.html5interactivemaps.com/
*/
class TRYJSMAPIII {
  public function __construct(){
    $this->constant();
    $this->options = get_option( 'try_js_map_iii' );
    add_action( 'admin_menu', array($this, 'try_js_map_iii_options_page') );
    add_action( 'admin_footer', array( $this,'add_js_to_wp_footer') );
    add_action( 'wp_footer', array($this,'add_span_tag') );
    add_action( 'admin_enqueue_scripts', array($this,'init_admin_script') );
    add_shortcode( 'try_js_map_iii', array($this, 'try_js_map_iii') );
  }
  protected function constant(){
    define( 'TRYJSMAPIII_VERSION', '1.0' );
    define( 'TRYJSMAPIII_DIR', plugin_dir_path( __FILE__ ) );
    define( 'TRYJSMAPIII_URL', plugin_dir_url( __FILE__ ) );
  }
  public function try_js_map_iii(){
    ob_start();
    include 'design/map.php';
    ?>
    <?php
    wp_enqueue_style( 'try-js-mapstyle-frontend', TRYJSMAPIII_URL . 'map-style.css', false, '1.0', 'all' );
    wp_enqueue_script( 'try-js-map-config', TRYJSMAPIII_URL . 'map-config.js', array('jquery'), 10, '1.0', true );
    wp_enqueue_script( 'try-js-pins-config', TRYJSMAPIII_URL . 'pins-config.js', array('jquery'), 10, '1.0', true );
    wp_enqueue_script( 'try-js-map-interact', TRYJSMAPIII_URL . 'map-interact.js', array('jquery'), 10, '1.0', true );
    $html = ob_get_clean();
    return $html;
  }
  public function try_js_map_iii_options_page() {
    add_menu_page('Trial JS Map III', 'Trial JS Map III', 'manage_options', 'try-js-map-iii', array($this, 'options_screen'), TRYJSMAPIII_URL . 'design/map-icon.png');
  }
  public function admin_ajax_url(){
    $url_action = admin_url( '/' ) . 'admin-ajax.php';
    echo '<div style="display:none" id="wpurl">'. $url_action.'</div>';
  }
	public function options_screen(){ 
    ?>
    <?php include 'design/admin.php';
  }
  public function add_js_to_wp_footer(){
    ?>
    <span id="tryjstip" style="margin-top:-32px"></span>
    <?php
  }
  public function add_span_tag(){
    ?>
    <span id="tryjstip"></span>
    <?php
  }
  public function stripslashes_deep($value) {
    $value = is_array($value) ?
    array_map(array($this, 'stripslashes_deep'), $value) : stripslashes($value);
    return $value;
  }
  public function init_admin_script(){
    if(isset($_GET['page']) && $_GET['page'] == 'try-js-map-iii'):
      wp_enqueue_style( 'try-js-map-style', TRYJSMAPIII_URL . 'map-admin-style.css', false, '1.0', 'all' );
      wp_enqueue_style( 'try-js-mapstyle', TRYJSMAPIII_URL . 'map-style.css', false, '1.0', 'all' );
      wp_enqueue_script( 'try-js-map-config', TRYJSMAPIII_URL . 'map-config.js', array('jquery'), 10, '1.0', true );
      wp_enqueue_script( 'try-js-pins-config', TRYJSMAPIII_URL . 'pins-config.js', array('jquery'), 10, '1.0', true );
      wp_enqueue_script( 'try-js-map-interact', TRYJSMAPIII_URL . 'map-interact.js', array('jquery'), 10, '1.0', true );
      endif;
  }
}
$try_js_map_iii = new TRYJSMAPIII();