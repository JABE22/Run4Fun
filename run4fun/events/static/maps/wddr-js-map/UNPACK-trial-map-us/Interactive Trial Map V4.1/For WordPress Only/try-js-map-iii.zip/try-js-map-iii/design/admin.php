<?php $try_js_map_iii = $this->options; ?>
<form method="post" action="<?php echo admin_url( '/' ); ?>admin.php?page=try-js-map-iii">
<div id="map-admin">
  <div id="map-header">
    <p class="map-shortcode">Insert this shortcode <input type="text" value="[try_js_map_iii]" readonly> into any page or post to display the map.</p>
  </div>
  <div id="map-page">
    <div class="map-col-lt">
      <div id="map-preview">
        <?php include 'map.php'; ?>
      </div>
      <div class="map-settings">
        <div class="box-header">How to customize the map?</div>
        <div class="goconfig">
          <p>You can customize the map colors, links, hover information by direct editing of the plugin file 'map-config.js' (You don't need JavaScript knowledge to edit that file).</p>
          <p>You can add/remove pins by direct editing of the plugin file 'pins-config.js'. You can use the XY coordinates guide (included in the documentation) to get the X and Y values and use them in the 'pins-config.js' file.</p>
          <h3>How to access the customization files?</h3>
          <p class="no-margin-top-bot">You can access the files 'map-config.js' and 'pins-config.js' from your WordPress admin panel by the following steps:
            <ol>
              <li>Go to '<b>Plugins</b>' > '<b>Editor</b>', <span class="myhint">(If you don't see the Editor, click <a href="https://www.html5interactivemaps.com/assets/knowledge-base/index.html#missing-editor">here</a>)</span>.</li>
              <li>In the right side dropdown menu choose this plugin '<b>TRIAL JS MAP III</b>', and click 'select'.</li>
              <li>Click the file '<b>map-config.js</b>' or '<b>pins-config.js</b>' to open the editor.</li>
              <li>Make the required edits of colors, links, hover information, etc then click '<b>Update File</b>'.</li>
              <li>To see the change you need to clear the cache files ( <b>Ctrl</b> + <b>F5</b> ).</li>
            </ol>
          </p>
          <p></p>
          <p>We recommend keeping a copy of the content of the customization file, so you can return back to it as a history file.</p>
          <p>Please watch this short <a href="https://youtu.be/1mVlKKqWqWo">video</a> tutorial and check our <a href="https://www.html5interactivemaps.com/assets/knowledge-base/index.html">Knowldge Base</a> and feel free to contact us if you have any questions.</p>
        </div>
      </div><!-- map-settings / for areas -->
    </div><!-- map-col-lt -->

    <!-- General Map Colors -->
    <div class="map-col-rt">
      <div class="map-settings">
        <div class="box-header">Notes</div>
        <div class="goconfig">
          <p>You can use the shortcode as many times as you want to display the same map in different pages.</p>
          <p>If you want to have a different map with new colors and links, you can install a 2nd or 3rd instance of the plugin (included in the purchased files).</p>
        </div>
      </div><!-- map-settings -->
      <p><strong>Hint:</strong> you can set any color as "transparent" to hide the object.</p>
    </div><!-- map-col-rt -->

    <input type="hidden" name="try_js_map_iii">
      <?php
      settings_fields(__FILE__);
      do_settings_sections(__FILE__);
      ?>

  </div><!-- map-page -->
</div><!-- map-admin -->
</form>