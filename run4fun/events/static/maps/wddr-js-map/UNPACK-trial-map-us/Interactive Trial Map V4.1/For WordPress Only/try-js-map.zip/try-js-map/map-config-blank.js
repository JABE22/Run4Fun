﻿// This is similar to "map-config.js" with basic settings (colors, info., etc)
var tryjsconfig = {
  "tryjs1":{
    "hover": "AREA #1",//info of the popup
    "url": "https://www.html5interactivemaps.com/",//link to any webpage
    "target": "same_window",// use "new_window", "same_window", "modal", or "none"
    "upColor": "#FFFFF3",//default color
    "overColor": "#ECFFB3",//highlight color
    "downColor": "#cae9af",//clicking color
    "active": true//true/false to activate/deactivate
  },
  "tryjs2":{
    "hover": "AREA #2",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs3":{
    "hover": "AREA #3",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs4":{
    "hover": "AREA #4",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs5":{
    "hover": "AREA #5",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs6":{
    "hover": "AREA #6",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs7":{
    "hover": "AREA #7",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs8":{
    "hover": "AREA #8",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs9":{
    "hover": "AREA #9",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs10":{
    "hover": "AREA #10",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs11":{
    "hover": "AREA #11",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "tryjs12":{
    "hover": "AREA #12",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "general":{
    "borderColor": "#9CA8B6",
    "visibleNames": "#adadad"
  }
};